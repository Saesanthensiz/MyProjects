﻿namespace WorkProgram
{
    partial class WorkAddChe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorkAddChe));
            this.buttonCon = new System.Windows.Forms.Button();
            this.textBoxPoS = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxDatA = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxLasT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxFirsT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxGeN = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonEx = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonCon
            // 
            this.buttonCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCon.Location = new System.Drawing.Point(341, 309);
            this.buttonCon.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCon.Name = "buttonCon";
            this.buttonCon.Size = new System.Drawing.Size(95, 30);
            this.buttonCon.TabIndex = 24;
            this.buttonCon.Text = "Применить";
            this.buttonCon.UseVisualStyleBackColor = true;
            this.buttonCon.Click += new System.EventHandler(this.buttonCon_Click);
            // 
            // textBoxPoS
            // 
            this.textBoxPoS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxPoS.Location = new System.Drawing.Point(164, 200);
            this.textBoxPoS.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPoS.Name = "textBoxPoS";
            this.textBoxPoS.Size = new System.Drawing.Size(221, 24);
            this.textBoxPoS.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(31, 203);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 18);
            this.label6.TabIndex = 22;
            this.label6.Text = "Должность";
            // 
            // textBoxDatA
            // 
            this.textBoxDatA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxDatA.Location = new System.Drawing.Point(164, 154);
            this.textBoxDatA.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxDatA.Name = "textBoxDatA";
            this.textBoxDatA.Size = new System.Drawing.Size(221, 24);
            this.textBoxDatA.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(31, 157);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 18);
            this.label5.TabIndex = 20;
            this.label5.Text = "Дата рождения";
            // 
            // textBoxLasT
            // 
            this.textBoxLasT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxLasT.Location = new System.Drawing.Point(164, 106);
            this.textBoxLasT.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLasT.Name = "textBoxLasT";
            this.textBoxLasT.Size = new System.Drawing.Size(221, 24);
            this.textBoxLasT.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(31, 109);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 18);
            this.label4.TabIndex = 18;
            this.label4.Text = "Фамилия";
            // 
            // textBoxFirsT
            // 
            this.textBoxFirsT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxFirsT.Location = new System.Drawing.Point(164, 56);
            this.textBoxFirsT.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxFirsT.Name = "textBoxFirsT";
            this.textBoxFirsT.Size = new System.Drawing.Size(221, 24);
            this.textBoxFirsT.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(31, 59);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "Имя";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(149, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 18);
            this.label1.TabIndex = 13;
            this.label1.Text = "Заполните данные:";
            // 
            // textBoxGeN
            // 
            this.textBoxGeN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxGeN.Location = new System.Drawing.Point(164, 252);
            this.textBoxGeN.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxGeN.Name = "textBoxGeN";
            this.textBoxGeN.Size = new System.Drawing.Size(221, 24);
            this.textBoxGeN.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(32, 255);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 18);
            this.label7.TabIndex = 25;
            this.label7.Text = "Пол";
            // 
            // buttonEx
            // 
            this.buttonEx.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEx.Location = new System.Drawing.Point(214, 309);
            this.buttonEx.Margin = new System.Windows.Forms.Padding(2);
            this.buttonEx.Name = "buttonEx";
            this.buttonEx.Size = new System.Drawing.Size(95, 30);
            this.buttonEx.TabIndex = 27;
            this.buttonEx.Text = "Отмена";
            this.buttonEx.UseVisualStyleBackColor = true;
            this.buttonEx.Click += new System.EventHandler(this.buttonEx_Click);
            // 
            // WorkAddChe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(452, 354);
            this.Controls.Add(this.buttonEx);
            this.Controls.Add(this.textBoxGeN);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.buttonCon);
            this.Controls.Add(this.textBoxPoS);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxDatA);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxLasT);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxFirsT);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "WorkAddChe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Персонал";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCon;
        private System.Windows.Forms.TextBox textBoxPoS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxDatA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxLasT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxFirsT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxGeN;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonEx;
    }
}