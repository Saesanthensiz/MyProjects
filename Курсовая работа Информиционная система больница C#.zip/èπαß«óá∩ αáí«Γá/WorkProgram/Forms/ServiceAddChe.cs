﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    public partial class ServiceAddChe : Form
    {
        //переменные репозиториев
        WorkersRep workersRep = new WorkersRep();
        ServicesRep servicesRep = new ServicesRep();
        VisitsRep visitsRep = new VisitsRep();
        //текущая запись для изменения
        Services CurSer;

        /// <summary>
        ///  флаг указывающий на изменение
        /// </summary>
        bool flag = false;

        public ServiceAddChe()
        {
            try
            {
                InitializeComponent();
                //обновление списка работников
                workersRep.UpdateList(listBoxWorkers);
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        /// <summary>
        /// если в конструктор передаётся объект, то выболняетя изменение записи
        /// </summary>
        public ServiceAddChe(Services ser)
        {
            try
            {
                //изменение
                flag = true;
                CurSer = ser;
                InitializeComponent();
                //обновление списка
                workersRep.UpdateList(listBoxWorkers);
                //заполнение текстбоксов
                textBoxName.Text = ser.Name;
                textBoxPrice.Text = ser.Price;
                richTextBox1.Text = ser.Information;
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        private void buttonContinue_Click(object sender, EventArgs e)
        {
            try
            {
                //проветка полей на пустоту
                if (textBoxName.Text.Length == 0 || textBoxPrice.Text.Length == 0)
                {
                    MessageBox.Show("Введите данные", "Ошибка");
                    return;
                }

                //проверка на выбор работника
                if(listBoxWorkers.SelectedItems.Count == 0)
                {
                    MessageBox.Show("Выберите работника", "Ошибка");
                    return;
                }

                //полученик id работника
                Workers work = workersRep.Get(listBoxWorkers.SelectedItem.ToString(), true);

                //новая услуга
                Services service = new Services();
                service.Name = textBoxName.Text;
                service.Price = textBoxPrice.Text;
                service.Workers = work.Id;
                service.Information = richTextBox1.Text;

                if (flag == true)
                {
                    //подтверждение
                    DialogResult dialogResult = MessageBox.Show("При изменении услуги все посещения связанные с ней будут удалены!\nПродолжить?", "Подтверждение", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                    try
                    {
                        //удаление посещений
                        List<Visits> list = visitsRep.GetList();
                        foreach (var visits in list)
                        {
                            if (visits.Service == CurSer.Id)
                            {
                                //удаление
                                visitsRep.Delete(visits.Id);
                            }
                        }
                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }
                }

                try
                {
                    //перед сохранием нужно удалить текущию запись
                    servicesRep.Delete(CurSer.Id);
                }
                catch
                {
                    //если ошибка - удалять нечего
                }

            m1:
                //получение нового id
                string newID = Convert.ToString(frmMenu.NewID(ref frmMenu.idVarSer));
                service.Id = newID;

                try
                {
                    //попытка создания, если не удачно, то id существует и присвоение нового
                    servicesRep.Create(service);      
                }

                catch (Exception ex)
                {

                    //код ошибки при существующем ID
                    if (ex.HResult == -2146233087)
                    {
                        goto m1;   
                    }
                }
 
                MessageBox.Show("Успешно", "Результат выполнения");

                if(flag == true)
                {
                    this.Close();
                }
                //очистка полей
                textBoxName.Clear();
                textBoxPrice.Clear();
                richTextBox1.Clear();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        //выход из формы
        private void buttonEx_Click(object sender, EventArgs e)
        {
            this.Close();
        }   
    }
}
