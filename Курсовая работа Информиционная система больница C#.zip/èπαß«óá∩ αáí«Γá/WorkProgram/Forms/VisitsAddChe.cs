﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    public partial class VisitsAddChe : Form
    {
        //переменные репозиториев
        CustomersRep customersRep = new CustomersRep();
        ServicesRep servicesRep = new ServicesRep();
        VisitsRep visitsRep = new VisitsRep();
        //текущая запись для изменения
        Visits CurVis = new Visits();

        /// <summary>
        ///  флаг указывающий на изменение
        /// </summary>
        bool flagChe = false;

        public VisitsAddChe()
        {
            try
            {
                InitializeComponent();
                //обновление списков
                customersRep.UpdateList(listBoxCust);
                servicesRep.UpdateList(listBoxServices);
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        /// <summary>
        /// если в конструктор передаётся объект, то выболняетя изменение записи
        /// </summary>
        public VisitsAddChe(Visits visit)
        {
            try
            {
                flagChe = true;
                CurVis = visit;
                InitializeComponent();
                //обновление списков
                customersRep.UpdateList(listBoxCust);
                servicesRep.UpdateList(listBoxServices);
                //заполнение даты
                textBoxDate.Text = Convert.ToString(visit.Date);
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        private void buttonCon_Click(object sender, EventArgs e)
        {
            try
            {
                //проветка полей на пустоту
                if (textBoxDate.Text.Length == 0)
                {
                    MessageBox.Show("Введите дату!", "Ошибка");
                    return;
                }

                //выбрана ли услуга
                if (listBoxServices.SelectedItems.Count == 0)
                {
                    MessageBox.Show("Выберите услугу", "Ошибка");
                    return;
                }

                //выбран ли клиент
                if (listBoxCust.SelectedItems.Count == 0)
                {
                    MessageBox.Show("Выберите клиента", "Ошибка");
                    return;
                }

                //полученик id клиенты
                Customers customer = customersRep.Get(listBoxCust.SelectedItem.ToString(),true);
                //полученик id услуги
                Services service= servicesRep.Get(listBoxServices.SelectedItem.ToString(), true);
                Visits newVisit = new Visits();
                
                try
                {
                    newVisit.Date = Convert.ToDateTime(textBoxDate.Text);
                }
                catch
                {
                    MessageBox.Show("Введите корректную дату(дд.мм.гггг)", "Ошибка");
                    return;
                }
                
                newVisit.Customer = customer.Id;
                newVisit.Service = service.Id;

                //перед сохранием нужно удалить текущию запись
                if (flagChe == true)
                {
                    visitsRep.Delete(CurVis.Id);
                }

            m1:
                //получение нового id
                string newID = Convert.ToString(frmMenu.NewID(ref frmMenu.idVarVis));
                newVisit.Id = newID;

                try
                {
                    //попытка создания, если не удачно, то id существует и присвоение нового
                    visitsRep.Create(newVisit);
                }
                catch (Exception ex)
                {
                    //код ошибки при существующем ID
                    if (ex.HResult == -2146233087)
                    {
                        goto m1;
                    }
                }

                MessageBox.Show("Успешно", "Результат выполнения");
                if (flagChe == true)
                {
                    this.Close();
                }
                textBoxDate.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка");
            }
        }

        //выход из формы
        private void buttonEx_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
