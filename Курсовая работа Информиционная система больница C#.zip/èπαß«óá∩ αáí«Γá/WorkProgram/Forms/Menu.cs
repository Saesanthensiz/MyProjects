﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WorkProgram
{
    public partial class frmMenu : Form
    {
        /// <summary>
        /// функция нового ID
        /// </summary>
        public static long NewID(ref long idVar)
        {
            idVar++;
            return idVar;
        }

        //переменные для хранения ID
        public static long idVarSer = 1;
        public static long idVarVis = 1;
        public static long idVarWork = 1;
        public static long idVarCust = 1;

        //репозитории
        ServicesRep servicesRep = new ServicesRep();
        CustomersRep customersRep = new CustomersRep();
        WorkersRep workersRep = new WorkersRep();
        VisitsRep visitsRep = new VisitsRep();

        public frmMenu()
        {
            InitializeComponent();
        }

        //фокус на форму
        private void Menu_Activated(object sender, EventArgs e)
        {

            try
            {
                //очищение
                dataGridViewSer.Rows.Clear();
                dataGridViewVisit.Rows.Clear();
                dataGridViewCust.Rows.Clear();
                dataGridViewWork.Rows.Clear();

                //обновленик таблиц
                servicesRep.UpdateDataGrid(dataGridViewSer);
                visitsRep.UpdateDataGrid(dataGridViewVisit);
                customersRep.UpdateDataGrid(dataGridViewCust);
                workersRep.UpdateDataGrid(dataGridViewWork);
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message.ToString(), "Ошибка");
            }
        } 

        //добавление услуги
        private void ServiceAdd_Click(object sender, EventArgs e)
        {
            ServiceAddChe serv = new ServiceAddChe();
            serv.ShowDialog();
            
        }

        //изменение услуги
        private void ServiceChe_Click(object sender, EventArgs e)
        {
            try
            {
                //получение текущей услуги
                Services services = servicesRep.Get(this.dataGridViewSer.CurrentRow.Cells[0].Value.ToString());
                ServiceAddChe frm = new ServiceAddChe(services);
                frm.ShowDialog();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message.ToString(), "Ошибка");
            }
        }

        //удаление услуги
        private void ServiceDel_Click(object sender, EventArgs e)
        {
            try
            {
                Services services = new Services();
   
                try
                {
                    //получение текущей услуги, если ошибка, то услуга не выбрана
                    services = servicesRep.Get(this.dataGridViewSer.CurrentRow.Cells[0].Value.ToString());
                }
                catch
                {
                    MessageBox.Show("Выберите одину из услуг!", "Результат выполнения");
                    return;
                }

                //подтверждение выбора
                DialogResult dialogResult = MessageBox.Show("Вы уверены что хотите удалить выбранную услугу?\nПри удалении услуги будут удалены все посещения связанные с ней!!", "Подтверждение", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        //создание списка посещений на удаление
                        List<Visits> listForDel = visitsRep.GetList();

                        foreach (var visits in listForDel)
                        {
                            //поиск посещений
                            if (visits.Service == services.Id)
                            {
                                //удаление
                                visitsRep.Delete(visits.Id);
                                
                            }
                        }
                    }
                    catch (Exception x)
                    {
                        MessageBox.Show(x.Message.ToString(), "Удаление визита");
                    }

                    try
                    {
                        //удаление текущей услуги
                        servicesRep.Delete(services.Id);
                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }
                    MessageBox.Show("Успешно!", "Результат выполнения");
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        //добаление клиента
        private void CustAdd_Click(object sender, EventArgs e)
        {
            CustomersAddChe cust = new CustomersAddChe();
            cust.ShowDialog();
        }

        // изменение клиента
        private void CustChe_Click(object sender, EventArgs e)
        {
            try
            {
                //получение текущего клиента
                Customers customers = customersRep.Get(this.dataGridViewCust.CurrentRow.Cells[0].Value.ToString());
                CustomersAddChe frm = new CustomersAddChe(customers);
                frm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка");
            }
        }

        //удаление клиенда
        private void CustDel_Click(object sender, EventArgs e)
        {
            try
            {
                Customers customers = new Customers();
                try
                {
                    //получение текущего клиента, если ошибка, то клиент не выбран
                    customers = customersRep.Get(this.dataGridViewCust.CurrentRow.Cells[0].Value.ToString());
                }
                catch
                {
                    MessageBox.Show("Выберите одиного из клиентов!", "Результат выполнения");
                    return;
                }

                //подтверждение выбора
                DialogResult dialogResult = MessageBox.Show("Вы уверены что хотите удалить выбранного клиента?\nПри удалении клиента будут удалены все посещения связанные с ним!", "Подтверждение", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    try
                    {
                        //создание списка посещений на удаление
                        List<Visits> list = visitsRep.GetList();

                        foreach (var visits in list)
                        {
                            //поиск посещений
                            if (visits.Customer == customers.Id)
                            {
                                //удалени
                                visitsRep.Delete(visits.Id);
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(), "Удаление визита");
                    }

                    try
                    {
                        //удаление клиента
                        customersRep.Delete(customers.Id);
                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }
                    MessageBox.Show("Успешно!", "Результат выполнения");
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        //добавление работника
        private void WorkAdd_Click(object sender, EventArgs e)
        {
            WorkAddChe work = new WorkAddChe();
            work.ShowDialog();
        }

        //изменение работника
        private void WorkChe_Click(object sender, EventArgs e)
        {
            try
            {
                //получение текущего работника
                Workers workers = workersRep.Get(this.dataGridViewWork.CurrentRow.Cells[0].Value.ToString());
                WorkAddChe work = new WorkAddChe(workers);
                work.ShowDialog();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message.ToString(), "Ошибка");
            }
        }

        //удаление работника
        private void WorkDel_Click(object sender, EventArgs e)
        {
            try
            {
                Workers workers = new Workers();
                try
                {
                    //получение текущего работника, ошибка - не выбран
                    workers = workersRep.Get(this.dataGridViewWork.CurrentRow.Cells[0].Value.ToString());
                }
                catch
                {
                    MessageBox.Show("Выберите одиного из работников!", "Результат выполнения");
                    return;
                }

                //подтверждение
                DialogResult dialogResult = MessageBox.Show("Вы уверены что хотите удалить выбранного работника?\nПри удалении работнника будут удалены все услуги и посещения связанные с ним!", "Подтверждение", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        //список услуг на удаление
                        List<Services> listSerDel = servicesRep.GetList();

                        foreach (var services in listSerDel)
                        {
                            //поиск услуг
                            if (services.Workers == workers.Id)
                            {
                                try
                                {
                                    //список посещений
                                    List<Visits> listVisDel = visitsRep.GetList();

                                    //поиск посещений
                                    foreach (var visits in listVisDel)
                                    {
                                        if (visits.Service == services.Id)
                                        {
                                            //удаление посещений
                                            visitsRep.Delete(visits.Id);
                                        }
                                    }
                                }
                                catch
                                {
                                    //если ошибка - удалять нечего
                                }

                                // удаление услуги
                                servicesRep.Delete(services.Id);
                            }
                        }
                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }

                    try
                    {
                        // удаление работника
                        workersRep.Delete(workers.Id);

                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }
                    MessageBox.Show("Успешно!", "Результат выполнения");
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        //добавление посещений
        private void VisitsAdd_Click(object sender, EventArgs e)
        {
            VisitsAddChe visit = new VisitsAddChe();
            visit.ShowDialog();
        }

        //изменение посещения
        private void VisitsChe_Click(object sender, EventArgs e)
        {
            try
            {
                //получение текущего
                Visits visits = visitsRep.Get(this.dataGridViewVisit.CurrentRow.Cells[0].Value.ToString());
                VisitsAddChe visit = new VisitsAddChe(visits);
                visit.ShowDialog();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message.ToString(), "Ошибка");
            }
        }

        //удаление посещения
        private void VisitsDel_Click(object sender, EventArgs e)
        {
            try
            {
                Visits visits = new Visits();

                try
                { 
                    //получение текущего
                    visits = visitsRep.Get(this.dataGridViewVisit.CurrentRow.Cells[0].Value.ToString());
                }
                catch
                {
                    MessageBox.Show("Выберите одино из посещений!", "Результат выполнения");
                    return;
                }

                //подтверждение
                DialogResult dialogResult = MessageBox.Show("Вы уверены что хотите удалить выбранное посещение?", "Подтверждение", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        //удаление
                        visitsRep.Delete(visits.Id);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString(), "Ошибка");
                    }

                    MessageBox.Show("Успешно!", "Результат выполнения");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка");
            }
        }

    }
}
