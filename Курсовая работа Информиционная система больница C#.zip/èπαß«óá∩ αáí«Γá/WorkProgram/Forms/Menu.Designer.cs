﻿namespace WorkProgram
{
    partial class frmMenu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenu));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ServiceDel = new System.Windows.Forms.Button();
            this.ServiceChe = new System.Windows.Forms.Button();
            this.ServiceAdd = new System.Windows.Forms.Button();
            this.dataGridViewSer = new System.Windows.Forms.DataGridView();
            this.Id_ser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Workers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Information = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.VisitsDel = new System.Windows.Forms.Button();
            this.VisitsChe = new System.Windows.Forms.Button();
            this.VisitsAdd = new System.Windows.Forms.Button();
            this.dataGridViewVisit = new System.Windows.Forms.DataGridView();
            this.Id_vis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CustDel = new System.Windows.Forms.Button();
            this.CustChe = new System.Windows.Forms.Button();
            this.CustAdd = new System.Windows.Forms.Button();
            this.dataGridViewCust = new System.Windows.Forms.DataGridView();
            this.Id_cust = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Informat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.WorkDel = new System.Windows.Forms.Button();
            this.WorkChe = new System.Windows.Forms.Button();
            this.WorkAdd = new System.Windows.Forms.Button();
            this.dataGridViewWork = new System.Windows.Forms.DataGridView();
            this.Id_Work = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirstNameWork = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastNameWork = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateBirth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSer)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisit)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCust)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWork)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(-4, -2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1920, 1050);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.tabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage1.BackgroundImage")));
            this.tabPage1.Controls.Add(this.ServiceDel);
            this.tabPage1.Controls.Add(this.ServiceChe);
            this.tabPage1.Controls.Add(this.ServiceAdd);
            this.tabPage1.Controls.Add(this.dataGridViewSer);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(1912, 1019);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Услуги";
            // 
            // ServiceDel
            // 
            this.ServiceDel.BackColor = System.Drawing.Color.White;
            this.ServiceDel.Location = new System.Drawing.Point(857, 594);
            this.ServiceDel.Margin = new System.Windows.Forms.Padding(2);
            this.ServiceDel.Name = "ServiceDel";
            this.ServiceDel.Size = new System.Drawing.Size(90, 30);
            this.ServiceDel.TabIndex = 3;
            this.ServiceDel.Text = "Удалить";
            this.ServiceDel.UseVisualStyleBackColor = false;
            this.ServiceDel.Click += new System.EventHandler(this.ServiceDel_Click);
            // 
            // ServiceChe
            // 
            this.ServiceChe.BackColor = System.Drawing.Color.White;
            this.ServiceChe.Location = new System.Drawing.Point(1004, 594);
            this.ServiceChe.Margin = new System.Windows.Forms.Padding(2);
            this.ServiceChe.Name = "ServiceChe";
            this.ServiceChe.Size = new System.Drawing.Size(90, 30);
            this.ServiceChe.TabIndex = 2;
            this.ServiceChe.Text = "Изменить";
            this.ServiceChe.UseVisualStyleBackColor = false;
            this.ServiceChe.Click += new System.EventHandler(this.ServiceChe_Click);
            // 
            // ServiceAdd
            // 
            this.ServiceAdd.BackColor = System.Drawing.Color.White;
            this.ServiceAdd.Location = new System.Drawing.Point(1150, 594);
            this.ServiceAdd.Margin = new System.Windows.Forms.Padding(2);
            this.ServiceAdd.Name = "ServiceAdd";
            this.ServiceAdd.Size = new System.Drawing.Size(90, 30);
            this.ServiceAdd.TabIndex = 1;
            this.ServiceAdd.Text = "Добавить";
            this.ServiceAdd.UseVisualStyleBackColor = false;
            this.ServiceAdd.Click += new System.EventHandler(this.ServiceAdd_Click);
            // 
            // dataGridViewSer
            // 
            this.dataGridViewSer.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(65)))), ((int)(((byte)(75)))));
            this.dataGridViewSer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id_ser,
            this.Name_,
            this.Price,
            this.Workers,
            this.Information});
            this.dataGridViewSer.Location = new System.Drawing.Point(-40, -1);
            this.dataGridViewSer.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewSer.Name = "dataGridViewSer";
            this.dataGridViewSer.RowTemplate.Height = 28;
            this.dataGridViewSer.Size = new System.Drawing.Size(1312, 557);
            this.dataGridViewSer.TabIndex = 0;
            // 
            // Id_ser
            // 
            this.Id_ser.HeaderText = "id";
            this.Id_ser.Name = "Id_ser";
            this.Id_ser.Visible = false;
            // 
            // Name_
            // 
            this.Name_.HeaderText = "Name";
            this.Name_.Name = "Name_";
            this.Name_.Width = 300;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.Width = 302;
            // 
            // Workers
            // 
            this.Workers.HeaderText = "Workers";
            this.Workers.Name = "Workers";
            this.Workers.Width = 310;
            // 
            // Information
            // 
            this.Information.HeaderText = "Information";
            this.Information.Name = "Information";
            this.Information.Width = 350;
            // 
            // tabPage2
            // 
            this.tabPage2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage2.BackgroundImage")));
            this.tabPage2.Controls.Add(this.VisitsDel);
            this.tabPage2.Controls.Add(this.VisitsChe);
            this.tabPage2.Controls.Add(this.VisitsAdd);
            this.tabPage2.Controls.Add(this.dataGridViewVisit);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(1912, 1019);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Посещения";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // VisitsDel
            // 
            this.VisitsDel.BackColor = System.Drawing.Color.White;
            this.VisitsDel.Location = new System.Drawing.Point(857, 594);
            this.VisitsDel.Margin = new System.Windows.Forms.Padding(2);
            this.VisitsDel.Name = "VisitsDel";
            this.VisitsDel.Size = new System.Drawing.Size(90, 30);
            this.VisitsDel.TabIndex = 6;
            this.VisitsDel.Text = "Удалить";
            this.VisitsDel.UseVisualStyleBackColor = false;
            this.VisitsDel.Click += new System.EventHandler(this.VisitsDel_Click);
            // 
            // VisitsChe
            // 
            this.VisitsChe.BackColor = System.Drawing.Color.White;
            this.VisitsChe.Location = new System.Drawing.Point(1004, 594);
            this.VisitsChe.Margin = new System.Windows.Forms.Padding(2);
            this.VisitsChe.Name = "VisitsChe";
            this.VisitsChe.Size = new System.Drawing.Size(90, 30);
            this.VisitsChe.TabIndex = 5;
            this.VisitsChe.Text = "Изменить";
            this.VisitsChe.UseVisualStyleBackColor = false;
            this.VisitsChe.Click += new System.EventHandler(this.VisitsChe_Click);
            // 
            // VisitsAdd
            // 
            this.VisitsAdd.BackColor = System.Drawing.Color.White;
            this.VisitsAdd.Location = new System.Drawing.Point(1150, 594);
            this.VisitsAdd.Margin = new System.Windows.Forms.Padding(2);
            this.VisitsAdd.Name = "VisitsAdd";
            this.VisitsAdd.Size = new System.Drawing.Size(90, 30);
            this.VisitsAdd.TabIndex = 4;
            this.VisitsAdd.Text = "Добавить";
            this.VisitsAdd.UseVisualStyleBackColor = false;
            this.VisitsAdd.Click += new System.EventHandler(this.VisitsAdd_Click);
            // 
            // dataGridViewVisit
            // 
            this.dataGridViewVisit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(65)))), ((int)(((byte)(75)))));
            this.dataGridViewVisit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVisit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id_vis,
            this.Customers,
            this.Service,
            this.Date});
            this.dataGridViewVisit.Location = new System.Drawing.Point(-40, -1);
            this.dataGridViewVisit.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewVisit.Name = "dataGridViewVisit";
            this.dataGridViewVisit.RowTemplate.Height = 28;
            this.dataGridViewVisit.Size = new System.Drawing.Size(1312, 557);
            this.dataGridViewVisit.TabIndex = 0;
            // 
            // Id_vis
            // 
            this.Id_vis.HeaderText = "Id";
            this.Id_vis.Name = "Id_vis";
            this.Id_vis.Visible = false;
            // 
            // Customers
            // 
            this.Customers.HeaderText = "Customers";
            this.Customers.Name = "Customers";
            this.Customers.Width = 400;
            // 
            // Service
            // 
            this.Service.HeaderText = "Service";
            this.Service.Name = "Service";
            this.Service.Width = 430;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.Width = 432;
            // 
            // tabPage3
            // 
            this.tabPage3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage3.BackgroundImage")));
            this.tabPage3.Controls.Add(this.CustDel);
            this.tabPage3.Controls.Add(this.CustChe);
            this.tabPage3.Controls.Add(this.CustAdd);
            this.tabPage3.Controls.Add(this.dataGridViewCust);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1912, 1019);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Клиенты";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // CustDel
            // 
            this.CustDel.BackColor = System.Drawing.Color.White;
            this.CustDel.Location = new System.Drawing.Point(857, 594);
            this.CustDel.Margin = new System.Windows.Forms.Padding(2);
            this.CustDel.Name = "CustDel";
            this.CustDel.Size = new System.Drawing.Size(90, 30);
            this.CustDel.TabIndex = 9;
            this.CustDel.Text = "Удалить";
            this.CustDel.UseVisualStyleBackColor = false;
            this.CustDel.Click += new System.EventHandler(this.CustDel_Click);
            // 
            // CustChe
            // 
            this.CustChe.BackColor = System.Drawing.Color.White;
            this.CustChe.Location = new System.Drawing.Point(1004, 594);
            this.CustChe.Margin = new System.Windows.Forms.Padding(2);
            this.CustChe.Name = "CustChe";
            this.CustChe.Size = new System.Drawing.Size(90, 30);
            this.CustChe.TabIndex = 8;
            this.CustChe.Text = "Изменить";
            this.CustChe.UseVisualStyleBackColor = false;
            this.CustChe.Click += new System.EventHandler(this.CustChe_Click);
            // 
            // CustAdd
            // 
            this.CustAdd.BackColor = System.Drawing.Color.White;
            this.CustAdd.Location = new System.Drawing.Point(1150, 594);
            this.CustAdd.Margin = new System.Windows.Forms.Padding(2);
            this.CustAdd.Name = "CustAdd";
            this.CustAdd.Size = new System.Drawing.Size(90, 30);
            this.CustAdd.TabIndex = 7;
            this.CustAdd.Text = "Добавить";
            this.CustAdd.UseVisualStyleBackColor = false;
            this.CustAdd.Click += new System.EventHandler(this.CustAdd_Click);
            // 
            // dataGridViewCust
            // 
            this.dataGridViewCust.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(65)))), ((int)(((byte)(75)))));
            this.dataGridViewCust.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCust.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id_cust,
            this.FirName,
            this.LastName,
            this.PhoneNumber,
            this.Informat});
            this.dataGridViewCust.Location = new System.Drawing.Point(-40, -1);
            this.dataGridViewCust.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewCust.Name = "dataGridViewCust";
            this.dataGridViewCust.RowTemplate.Height = 28;
            this.dataGridViewCust.Size = new System.Drawing.Size(1312, 557);
            this.dataGridViewCust.TabIndex = 0;
            // 
            // Id_cust
            // 
            this.Id_cust.HeaderText = "Id";
            this.Id_cust.Name = "Id_cust";
            this.Id_cust.Visible = false;
            // 
            // FirName
            // 
            this.FirName.HeaderText = "FirstName";
            this.FirName.Name = "FirName";
            this.FirName.Width = 300;
            // 
            // LastName
            // 
            this.LastName.HeaderText = "LastName";
            this.LastName.Name = "LastName";
            this.LastName.Width = 300;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.HeaderText = "PhoneNumber";
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Width = 320;
            // 
            // Informat
            // 
            this.Informat.HeaderText = "Information";
            this.Informat.Name = "Informat";
            this.Informat.Width = 343;
            // 
            // tabPage4
            // 
            this.tabPage4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage4.BackgroundImage")));
            this.tabPage4.Controls.Add(this.WorkDel);
            this.tabPage4.Controls.Add(this.WorkChe);
            this.tabPage4.Controls.Add(this.WorkAdd);
            this.tabPage4.Controls.Add(this.dataGridViewWork);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1912, 1019);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Персонал";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // WorkDel
            // 
            this.WorkDel.BackColor = System.Drawing.Color.White;
            this.WorkDel.Location = new System.Drawing.Point(857, 594);
            this.WorkDel.Margin = new System.Windows.Forms.Padding(2);
            this.WorkDel.Name = "WorkDel";
            this.WorkDel.Size = new System.Drawing.Size(90, 30);
            this.WorkDel.TabIndex = 6;
            this.WorkDel.Text = "Удалить";
            this.WorkDel.UseVisualStyleBackColor = false;
            this.WorkDel.Click += new System.EventHandler(this.WorkDel_Click);
            // 
            // WorkChe
            // 
            this.WorkChe.BackColor = System.Drawing.Color.White;
            this.WorkChe.Location = new System.Drawing.Point(1004, 594);
            this.WorkChe.Margin = new System.Windows.Forms.Padding(2);
            this.WorkChe.Name = "WorkChe";
            this.WorkChe.Size = new System.Drawing.Size(90, 30);
            this.WorkChe.TabIndex = 5;
            this.WorkChe.Text = "Изменить";
            this.WorkChe.UseVisualStyleBackColor = false;
            this.WorkChe.Click += new System.EventHandler(this.WorkChe_Click);
            // 
            // WorkAdd
            // 
            this.WorkAdd.BackColor = System.Drawing.Color.White;
            this.WorkAdd.Location = new System.Drawing.Point(1150, 594);
            this.WorkAdd.Margin = new System.Windows.Forms.Padding(2);
            this.WorkAdd.Name = "WorkAdd";
            this.WorkAdd.Size = new System.Drawing.Size(90, 30);
            this.WorkAdd.TabIndex = 4;
            this.WorkAdd.Text = "Добавить";
            this.WorkAdd.UseVisualStyleBackColor = false;
            this.WorkAdd.Click += new System.EventHandler(this.WorkAdd_Click);
            // 
            // dataGridViewWork
            // 
            this.dataGridViewWork.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(65)))), ((int)(((byte)(75)))));
            this.dataGridViewWork.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWork.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id_Work,
            this.FirstNameWork,
            this.LastNameWork,
            this.DateBirth,
            this.Position,
            this.Gender});
            this.dataGridViewWork.Location = new System.Drawing.Point(-40, -1);
            this.dataGridViewWork.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewWork.Name = "dataGridViewWork";
            this.dataGridViewWork.RowTemplate.Height = 28;
            this.dataGridViewWork.Size = new System.Drawing.Size(1312, 557);
            this.dataGridViewWork.TabIndex = 0;
            // 
            // Id_Work
            // 
            this.Id_Work.HeaderText = "Id";
            this.Id_Work.Name = "Id_Work";
            this.Id_Work.Visible = false;
            // 
            // FirstNameWork
            // 
            this.FirstNameWork.HeaderText = "FirstName";
            this.FirstNameWork.Name = "FirstNameWork";
            this.FirstNameWork.Width = 262;
            // 
            // LastNameWork
            // 
            this.LastNameWork.HeaderText = "LastName";
            this.LastNameWork.Name = "LastNameWork";
            this.LastNameWork.Width = 300;
            // 
            // DateBirth
            // 
            this.DateBirth.HeaderText = "Birthday";
            this.DateBirth.Name = "DateBirth";
            this.DateBirth.Width = 300;
            // 
            // Position
            // 
            this.Position.HeaderText = "Position";
            this.Position.Name = "Position";
            this.Position.Width = 200;
            // 
            // Gender
            // 
            this.Gender.HeaderText = "Gender";
            this.Gender.Name = "Gender";
            this.Gender.Width = 200;
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.Activated += new System.EventHandler(this.Menu_Activated);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSer)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisit)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCust)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWork)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridViewSer;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridViewVisit;
        private System.Windows.Forms.DataGridView dataGridViewCust;
        private System.Windows.Forms.DataGridView dataGridViewWork;
        private System.Windows.Forms.Button ServiceAdd;
        private System.Windows.Forms.Button ServiceChe;
        private System.Windows.Forms.Button ServiceDel;
        private System.Windows.Forms.Button VisitsDel;
        private System.Windows.Forms.Button VisitsChe;
        private System.Windows.Forms.Button VisitsAdd;
        private System.Windows.Forms.Button CustDel;
        private System.Windows.Forms.Button CustChe;
        private System.Windows.Forms.Button CustAdd;
        private System.Windows.Forms.Button WorkDel;
        private System.Windows.Forms.Button WorkChe;
        private System.Windows.Forms.Button WorkAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_ser;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name_;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Workers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Information;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_vis;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Service;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_cust;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Informat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_Work;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstNameWork;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastNameWork;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateBirth;
        private System.Windows.Forms.DataGridViewTextBoxColumn Position;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gender;
    }
}

