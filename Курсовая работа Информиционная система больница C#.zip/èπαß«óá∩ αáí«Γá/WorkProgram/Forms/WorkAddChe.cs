﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    public partial class WorkAddChe : Form
    {
        //переменные репозиториев
        ServicesRep servicesRep = new ServicesRep();
        VisitsRep visitsRep = new VisitsRep();
        WorkersRep workersRep = new WorkersRep();
        //текущая запись для изменения
        Workers CurWork;

        /// <summary>
        ///  флаг указывающий на изменение
        /// </summary>
        bool flag = false;
        public WorkAddChe()
        {
            InitializeComponent();
        }

        /// <summary>
        /// если в конструктор передаётся объект, то выболняетя изменение записи
        /// </summary>
        public WorkAddChe(Workers work)
        {
            try
            {
                flag = true;
                CurWork = work;
                InitializeComponent();
                //заполнение полей
                textBoxFirsT.Text = work.FirstName;
                textBoxLasT.Text = work.LastName;
                textBoxDatA.Text = Convert.ToString(work.DateBirth);
                textBoxPoS.Text = work.Position;
                textBoxGeN.Text = work.Gender;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка");
            }
        }

        private void buttonCon_Click(object sender, EventArgs e)
        {
            try
            {
                //проветка полей на пустоту
                if (textBoxFirsT.Text.Length == 0 || textBoxLasT.Text.Length == 0 || textBoxDatA.Text.Length == 0 || textBoxPoS.Text.Length == 0 || textBoxGeN.Text.Length == 0)
                {
                    MessageBox.Show("Введите данные", "Ошибка");
                    return;
                }

                //создание новой записи
                Workers newWork = new Workers();
                newWork.FirstName = textBoxFirsT.Text;
                newWork.LastName = textBoxLasT.Text;
                newWork.Position = textBoxPoS.Text;
                newWork.Gender = textBoxGeN.Text;
                try
                {
                    newWork.DateBirth = Convert.ToDateTime(textBoxDatA.Text);
                }
                catch
                {
                    MessageBox.Show("Введите корректную дату(дд.мм.гггг)", "Ошибка");
                    return;
                }

                if (flag == true)
                {
                    //подтверждение
                    DialogResult dialogResult = MessageBox.Show("При изменении работника все услуги и посещения связанные с ним будут удалены!\nПродолжить?", "Подтверждение", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                    try
                    {
                        List<Services> list = servicesRep.GetList();
                        //поиск всех связанных услуг
                        foreach (var services in list)
                        {
                            if (services.Workers == CurWork.Id)
                            {
                                try
                                {
                                    List<Visits> list1 = visitsRep.GetList();

                                    //поиск всех связанных посещений
                                    foreach (var visits in list1)
                                    {
                                        if (visits.Service == services.Id)
                                        {
                                            //удаление связвнного посещения
                                            visitsRep.Delete(visits.Id);
                                        }
                                    }
                                }
                                catch
                                {
                                    //если ошибка - удалять нечего
                                }
                                //удаление связанной услуги
                                servicesRep.Delete(services.Id);
                            }
                        }
                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }
                    try
                    {
                        //перед сохранием нужно удалить текущию запись
                        workersRep.Delete(CurWork.Id);

                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }
                }

            m1:
                //получение нового id
                string newID = Convert.ToString(frmMenu.NewID(ref frmMenu.idVarWork));
                newWork.Id = newID;

                try
                {
                    //попытка создания, если не удачно, то id существует и присвоение нового
                    workersRep.Create(newWork);
                }
                catch (Exception ex)
                {

                    //код ошибки при существующем ID
                    if (ex.HResult == -2146233087)
                    {
                        goto m1;
                    }
                } 

                MessageBox.Show("Успешно", "Результат выполнения");

                if (flag == true)
                {
                    this.Close();
                }

                //очистка полей
                textBoxFirsT.Clear();
                textBoxLasT.Clear();
                textBoxDatA.Clear();
                textBoxPoS.Clear();
                textBoxGeN.Clear();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        //выход из формы
        private void buttonEx_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
