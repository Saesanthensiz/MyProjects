﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    public partial class CustomersAddChe : Form
    {
        //переменные репозиториев
        CustomersRep customersRep = new CustomersRep();
        VisitsRep visitsRep = new VisitsRep();
        //текущая запись для изменения
        Customers CurCust;

        /// <summary>
        ///  флаг указывающий на изменение
        /// </summary>
        bool flag = false;

        public CustomersAddChe()
        {
            InitializeComponent();
        }

        /// <summary>
        /// если в конструктор передаётся объект, то выболняетя изменение записи
        /// </summary>
        public CustomersAddChe(Customers cust)
        {
            try
            {
                flag = true;
                CurCust = cust;
                InitializeComponent();
                //заполнение полей
                textBoxFirst.Text = cust.FirstName;
                textBoxLast.Text = cust.LastName;
                textBoxPhone.Text = cust.PhoneNumber;
                textBoxInf.Text = cust.Information;
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }

        }

        private void buttonCon_Click(object sender, EventArgs e)
        {
            try
            {
                //проветка полей на пустоту
                if (textBoxFirst.Text.Length == 0 || textBoxLast.Text.Length == 0 || textBoxPhone.Text.Length == 0 || textBoxInf.Text.Length == 0)
                {
                    MessageBox.Show("Введите данные", "Ошибка");
                    return;
                }

                //создание новой записи
                Customers newCust = new Customers();
                newCust.FirstName = textBoxFirst.Text;
                newCust.LastName = textBoxLast.Text;
                newCust.PhoneNumber = textBoxPhone.Text;
                newCust.Information = textBoxInf.Text;

                if (flag == true)
                {
                    //подтверждение
                    DialogResult dialogResult = MessageBox.Show("При изменении клиента все посещения связанные с ним будут удалены!\nПродолжить?", "Подтверждение", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                    try
                    {
                        List<Visits> list = visitsRep.GetList();

                        //поиск связанных посещений
                        foreach (var visits in list)
                        {
                            if (visits.Customer == CurCust.Id)
                            {
                                //удаленик
                                visitsRep.Delete(visits.Id);
                            }
                        }
                    }
                    catch
                    {
                        //если ошибка - удалять нечего
                    }

                }
                try
                {
                    //перед сохранием нужно удалить текущию запись
                    customersRep.Delete(CurCust.Id);
                }
                catch
                {
                    //если ошибка - удалять нечего
                }

            m1:
                //получение нового id
                string newID = Convert.ToString(frmMenu.NewID(ref frmMenu.idVarCust));
                newCust.Id = newID;

                try
                {
                    //попытка создания, если не удачно, то id существует и присвоение нового
                    customersRep.Create(newCust);
                }
                catch (Exception ex)
                {

                    //код ошибки при существующем ID
                    if (ex.HResult == -2146233087)
                    {
                        goto m1;
                    }
                }

                MessageBox.Show("Успешно", "Результат выполнения");
                if (flag == true)
                {
                    this.Close();
                }
                //очищение полей
                textBoxFirst.Clear();
                textBoxLast.Clear();
                textBoxPhone.Clear();
                textBoxInf.Clear();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        //закрытие формы
        private void buttonEx_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
