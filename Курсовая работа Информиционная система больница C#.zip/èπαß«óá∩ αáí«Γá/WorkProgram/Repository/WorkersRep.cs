﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    class WorkersRep : IDataServer<Workers>
    { 
        //переменная для реботы с базой данных
        private DataBaseEntities _dataBase = new DataBaseEntities();

        /// <summary>
        /// получение объекта по id
        /// </summary>
        public Workers Get(string id)
        {
            Workers work = _dataBase.Workers.Where(worker => worker.Id == id).First();
            return work;
        }

        /// <summary>
        /// получение объекта по имени, "а" для перегрузки 
        /// </summary>
        public Workers Get(string FirstName, bool a)
        {
            Workers work = _dataBase.Workers.Where(worker => worker.FirstName == FirstName).First();
            return work;
        }

        /// <summary>
        /// получение списка записей таблицы
        /// </summary>
        public List<Workers> GetList()
        {
            //запрос
            var query = from worker in _dataBase.Workers select worker;
            
            List<Workers> list = new List<Workers>();

            //поиск
            foreach (var workers in query)
            {
                Workers work = _dataBase.Workers.Where(worker => worker.Id == workers.Id).First();
                list.Add(work);
            }

            return list;
        }

        /// <summary>
        /// создание новой записи
        /// </summary>
        public void Create(Workers work)
        {
            _dataBase.Workers.Add(work);
            _dataBase.SaveChanges();
        }

        /// <summary>
        /// обновление списка
        /// </summary>
        public void UpdateList(ListBox list)
        {
            var query = from worker in _dataBase.Workers select worker;
            foreach (var workers in query)
            {
                //добавление к списку
                list.Items.Add(workers.FirstName);
            }
        }

        /// <summary>
        /// обновление таблицы
        /// </summary>
        public void UpdateDataGrid(DataGridView data)
        {
            try
            {
                var query = from worker in _dataBase.Workers select worker;
                foreach (var workers in query)
                {
                    //заполнение datagrid
                    data.Rows.Add(workers.Id, workers.FirstName, workers.LastName, workers.DateBirth, workers.Position, workers.Gender);
                }
            }
            catch
            {

            }
        }

        /// <summary>
        /// удаление записи по id
        /// </summary>
        public void Delete(string id)
        {

            Workers worker = _dataBase.Workers.Where(workers => workers.Id == id).First();
            if (worker != null)
                _dataBase.Workers.Remove(worker);
            _dataBase.SaveChanges();

        }

        private bool disposed = false;

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _dataBase.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
