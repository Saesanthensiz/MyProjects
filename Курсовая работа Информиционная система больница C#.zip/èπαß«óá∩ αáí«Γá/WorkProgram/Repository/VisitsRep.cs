﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    class VisitsRep : IDataServer<Visits>
    {
        //переменная для работы с базой
        private DataBaseEntities _dataBase = new DataBaseEntities();


        /// <summary>
        /// получение объекта по id
        /// </summary>
        public Visits Get(string id)
        {
            Visits vis = _dataBase.Visits.Where(visit => visit.Id == id).First();
            return vis;
        }

        /// <summary>
        /// получение списка записей таблицы
        /// </summary>
        public List<Visits> GetList()
        {
            //запрос
            var query = from visit in _dataBase.Visits select visit;

            List<Visits> list = new List<Visits>();
            //поиск
            foreach (var visits in query)
            {
                Visits vis = _dataBase.Visits.Where(visit => visit.Id == visits.Id).First();
                list.Add(vis);
            }

            return list;
        }

        /// <summary>
        /// создание новой записи
        /// </summary>
        public void Create (Visits vis)
        {
            _dataBase.Visits.Add(vis);
            _dataBase.SaveChanges();
        }

        /// <summary>
        /// удаление записи по id
        /// </summary>
        public void Delete(string id)
        {
            try
            {
                Visits visit = _dataBase.Visits.Where(vis => vis.Id == id).First();
                if (visit != null)
                    _dataBase.Visits.Remove(visit);
                _dataBase.SaveChanges();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Ошибка");
            }
        }

        /// <summary>
        /// обновление таблицы
        /// </summary>
        public void UpdateDataGrid(DataGridView data)
        {
            try
            {
                //запрос
                var query = from visit in _dataBase.Visits select visit;

                foreach (var visits in query)
                {
                    //получение имени клиента
                    CustomersRep CustRep = new CustomersRep();
                    Customers customer = CustRep.Get(visits.Customer);
                    //получение назвения услуги
                    ServicesRep SerRep = new ServicesRep();
                    Services service = SerRep.Get(visits.Service);
                    //заполнение datagrid
                    data.Rows.Add(visits.Id, customer.FirstName + " " + customer.LastName, service.Name, visits.Date);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка");
            }
        }

        private bool disposed = false;

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _dataBase.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
