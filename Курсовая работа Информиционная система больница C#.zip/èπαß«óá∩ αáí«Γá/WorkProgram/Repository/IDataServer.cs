﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    interface IDataServer<T> : IDisposable
        where T : class
    {
        // получение одного объекта
        T Get(string id);

        //получение списка объектов
        List<T> GetList();

        // создание объекта
        void Create(T item);

        // удаление объекта по id
        void Delete(string id);

        //прорисовка элемента dataGridView
        void UpdateDataGrid(DataGridView data);

    }
}
