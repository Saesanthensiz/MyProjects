﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    class ServicesRep : IDataServer<Services>
    { 
        //переменная для работы с базой
        private DataBaseEntities _dataBase = new DataBaseEntities();

        /// <summary>
        /// получение объекта по id
        /// </summary>
        public Services Get(string id)
        {
            Services ser = _dataBase.Services.Where(service => service.Id == id).First();
            return ser;
        }

        /// <summary>
        /// получение объекта по имени, "а" для перегрузки 
        /// </summary>
        public Services Get(string Name, bool a)
        {
            Services serv = _dataBase.Services.Where(service => service.Name == Name).First();
            return serv;
        }

        /// <summary>
        /// получение списка записей таблицы
        /// </summary>
        public List<Services> GetList()
        {
            //запрос
            var query = from service in _dataBase.Services select service;

            List<Services> list = new List<Services>();

            //поиск
            foreach (var services in query)
            {
                Services ser = _dataBase.Services.Where(service => service.Id == services.Id).First();
                list.Add(ser);
            }

            return list;
        }

        /// <summary>
        /// создание новой записи
        /// </summary>
        public void Create(Services ser)
        {
            _dataBase.Services.Add(ser);
            _dataBase.SaveChanges();
        }

        /// <summary>
        /// удаление записи по id
        /// </summary>
        public void Delete(string id)
        {

            Services service = _dataBase.Services.Where(services => services.Id == id).First();
            if (service != null)
                _dataBase.Services.Remove(service);
            _dataBase.SaveChanges();

        }

        /// <summary>
        /// обновление списка
        /// </summary>
        public void UpdateList(ListBox list)
        {
            //запрос
            var query = from service in _dataBase.Services select service;
            foreach (var services in query)
            {
                //добавление к списку
                list.Items.Add(services.Name);
            }
        }

        /// <summary>
        /// обновление таблицы
        /// </summary>
        public void UpdateDataGrid(DataGridView data)
        {
            try
            { 
                //запрос
                var query = from service in _dataBase.Services select service;

                //получение имени
                WorkersRep workersRep = new WorkersRep();
                foreach (var services in query)
                {
                    Workers work = workersRep.Get(services.Workers);

                    //заполнение datagrid
                    data.Rows.Add(services.Id, services.Name, services.Price, work.FirstName + " " + work.LastName, services.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка");
            }
        }

        private bool disposed = false;
      
        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _dataBase.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
