﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkProgram
{
    class CustomersRep : IDataServer<Customers>
    {
        //переменная для работы с базой
        private DataBaseEntities _dataBase = new DataBaseEntities();

        /// <summary>
        /// получение списка записей таблицы
        /// </summary>
        public Customers Get(string id)
        {
            Customers cust = _dataBase.Customers.Where(customer => customer.Id == id).First();
            return cust;
        }

        /// <summary>
        /// получение объекта по имени, "а" для перегрузки 
        /// </summary>
        public Customers Get(string FirstName, bool a)
        {
            Customers cust = _dataBase.Customers.Where(customer => customer.FirstName == FirstName).First();
            return cust;
        }

        /// <summary>
        /// получение списка записей таблицы
        /// </summary>
        public List<Customers> GetList()
        {
            var query = from customer in _dataBase.Customers select customer;

            List<Customers> list = new List<Customers>();

            foreach (var customers in query)
            {
                Customers cust = _dataBase.Customers.Where(customer => customer.Id == customers.Id).First();
                list.Add(cust);
            }

            return list;
        }

        /// <summary>
        /// создание новой записи
        /// </summary>
        public void Create(Customers cust)
        {
            _dataBase.Customers.Add(cust);
            _dataBase.SaveChanges();
        }

        /// <summary>
        /// удаление записи по id
        /// </summary>
        public void Delete(string id)
        {
            Customers customer = _dataBase.Customers.Where(customers => customers.Id == id).First();
            if (customer != null)
                _dataBase.Customers.Remove(customer);
            _dataBase.SaveChanges();

        }

        /// <summary>
        /// обновление списка
        /// </summary>
        public void UpdateList(ListBox list)
        {
            var query = from customer in _dataBase.Customers select customer;
            foreach (var customer in query)
            {
                //добавление в списку
                list.Items.Add(customer.FirstName);
            }
        }

        /// <summary>
        /// обновление таблицы
        /// </summary>
        public void UpdateDataGrid(DataGridView data)
        {
            try
            {
                var query = from customer in _dataBase.Customers select customer;

                foreach (var customers in query)
                {
                    //заполнение datagrid
                    data.Rows.Add(customers.Id, customers.FirstName, customers.LastName, customers.PhoneNumber, customers.Information);
                }
            }
            catch
            {

            }
        }

        private bool disposed = false;

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _dataBase.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        ///  метод очиски мусора
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
